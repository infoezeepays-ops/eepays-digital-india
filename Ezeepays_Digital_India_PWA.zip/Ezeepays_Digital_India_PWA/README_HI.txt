Ezeepays Digital India PWA — शुरुआती संस्करण

फाइलें:
- index.html: ऐप स्क्रीन
- style.css: मोबाइल डिज़ाइन
- app.js: बिक्री/स्टॉक/खर्च रिकॉर्ड और लोकल सेविंग
- manifest.webmanifest + sw.js: PWA install/offline support
- icon.svg: ऐप आइकन

इसे इंस्टॉल करने के लिए:
1. ZIP को extract करें।
2. सभी फाइलें HTTPS वाली static hosting पर अपलोड करें (उदाहरण: GitHub Pages या Netlify)।
3. Android फोन में Chrome से उस साइट को खोलें।
4. Chrome मेनू में “Install app” या “Add to Home screen” चुनें।
PWA install prompt कुछ ब्राउज़र/होस्टिंग स्थितियों में ही दिख सकता है।

महत्वपूर्ण सीमाएँ:
- यह native APK नहीं है; यह Progressive Web App (PWA) है।
- रिकॉर्ड उसी ब्राउज़र के localStorage में सेव होते हैं; सर्वर/क्लाउड sync नहीं है।
- ब्राउज़र डेटा हटने पर रिकॉर्ड खो सकते हैं। Reports में नियमित JSON backup डाउनलोड करें।
- यह GST/tax software नहीं है और बैंक/UPI से स्वतः कनेक्ट नहीं होता।
- Marketplace fee को Expenses में दोबारा जोड़ने से profit calculation double-count हो सकती है।
- पहले test entries के साथ जांचें और असली रिकॉर्ड शुरू करने से पहले backup बनाएं।
